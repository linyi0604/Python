#!/bin/bash

python3 ./main_58_spider.py
python3 ./main_ganji_spider.py
python3 ./main_anjuke_ereshoufang_spider.py
python3 ./main_anjuke_zufang_spider.py