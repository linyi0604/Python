#!/bin/bash
python3 ./main_ganji_spider.py