#!/bin/bash
python3 ./main_anjuke_ereshoufang_spider.py